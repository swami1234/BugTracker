﻿using BugTracker.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BugTracker.ViewModels
{
    public class ThreeViewModel
    {
        //public Project project = new Project();
        //public Ticket ticket = new Ticket();
        //public TicketComment ticketComment = new TicketComment();
        //public TicketHistory ticketHistory = new TicketHistory();
        //public TicketAttachment ticketAttachment = new TicketAttachment();
    }
}